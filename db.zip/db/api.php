<?php

$servername = "localhost";
$username = "maisy.baer";
$dbpassword = "smarty8Aa.g@";
$dbname = "sammanresorts";

// Create connection
$conn = new mysqli($servername, $username, $dbpassword, $dbname);

// Check connection
if ($conn->connect_error) {
    echo '<script>alert("Connection failed: ' . $conn->connect_error . '")</script>';
} else {
    //echo '<script>alert("Connection successful!")</script>';
}

?>



