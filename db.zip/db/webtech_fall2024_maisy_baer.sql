-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 17, 2024 at 06:58 PM
-- Server version: 8.0.40-0ubuntu0.24.04.1
-- PHP Version: 8.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webtech_fall2024_maisy_baer`
--

-- --------------------------------------------------------

--
-- Table structure for table `branches`
--

CREATE TABLE `branches` (
  `Branch_ID` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `Branch_Name` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `Branch_Location` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `Number_of_Rooms` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `branches`
--

INSERT INTO `branches` (`Branch_ID`, `Branch_Name`, `Branch_Location`, `Number_of_Rooms`) VALUES
('B001', 'Samaan Na-na Executive', 'Accra', 5),
('B002', 'Samaan Frimps Suites', 'Koforidua', 5),
('B003', 'Samaan Amar Resorts & Spa Two', 'Kwahu', 5),
('B004', 'Samaan Kiki Express Hotel Two', 'Kumsai', 5);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_ID` int NOT NULL,
  `Sex` char(1) COLLATE utf8mb4_general_ci NOT NULL,
  `DOB` date NOT NULL,
  `First_Name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Last_Name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `pword` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Phone_Number` varchar(15) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_ID`, `Sex`, `DOB`, `First_Name`, `Last_Name`, `Email`, `pword`, `Phone_Number`) VALUES
(4, 'F', '2003-11-15', 'Maisy', 'Baer', 'maisy.baer@gmail.com', '$2y$10$HGT4VT.gxoNib3FbisHEC.HO2nPpgwWMNi0vn5osOHT', '0507714047'),
(5, 'M', '2004-02-11', 'Nana A.', 'Boateng', 'nana.b@gmail.com', '$2y$10$55sFmO26UVBf4kc6wsHlAuNIsfpbzUTEIfJIuEtsfgw', '0000000000'),
(6, 'M', '0001-01-01', 'Test', 'User', 'test@gmail.com', 'testuser', '0000000000');

-- --------------------------------------------------------

--
-- Table structure for table `pending_booking`
--

CREATE TABLE `pending_booking` (
  `pending_booking_ID` int NOT NULL,
  `Customer_ID` int DEFAULT NULL,
  `Branch_ID` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Room_ID` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Check_In_Date` date DEFAULT NULL,
  `Check_Out_Date` date DEFAULT NULL,
  `Price` float DEFAULT NULL,
  `Branch_Location` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `Room_Name` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pending_service`
--

CREATE TABLE `pending_service` (
  `pending_service_ID` int NOT NULL,
  `Customer_ID` int NOT NULL,
  `Branch_ID` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `service_ID` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `Price` float DEFAULT NULL,
  `Branch_Location` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `service_type` varchar(225) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pending_service`
--

INSERT INTO `pending_service` (`pending_service_ID`, `Customer_ID`, `Branch_ID`, `service_ID`, `appointment_date`, `appointment_time`, `Price`, `Branch_Location`, `service_type`) VALUES
(10, 6, 'B001', 'S004', '2024-12-18', '14:16:00', 30, 'Accra', 'Yoga Class'),
(11, 6, 'B001', 'S004', '2024-12-18', '17:00:00', 30, 'Accra', 'Yoga Class'),
(12, 6, 'B003', 'S001', '2024-12-18', '15:25:00', 80, 'Kwahu', 'Full Body Massage'),
(13, 6, 'B001', 'S003', '2024-12-28', '17:01:00', 60, 'Accra', 'Gym');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `Room_ID` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `Room_Name` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `Room_Type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Room_Status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`Room_ID`, `Room_Name`, `Room_Type`, `Price`, `Room_Status`) VALUES
('R001', 'Deluxe Room', 'Single', 100.00, 0),
('R002', 'Superior Room', 'Double', 150.00, 3),
('R003', 'Executive Suite', 'Suite', 300.00, 5),
('R004', 'Standard Room', 'Single', 80.00, 5),
('R005', 'Family Suite', 'Suite', 200.00, 3),
('R006', 'Junior Suite', 'Suite', 130.00, 3),
('R007', 'Economy Room', 'Single', 60.00, 5);

-- --------------------------------------------------------

--
-- Table structure for table `room_booking`
--

CREATE TABLE `room_booking` (
  `room_booking_ID` int NOT NULL,
  `Customer_ID` int NOT NULL,
  `Room_ID` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `Branch_ID` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `Check_In_Date` date NOT NULL,
  `Check_Out_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_booking`
--

INSERT INTO `room_booking` (`room_booking_ID`, `Customer_ID`, `Room_ID`, `Branch_ID`, `Check_In_Date`, `Check_Out_Date`) VALUES
(7, 6, 'R002', 'B003', '2024-12-19', '2024-12-28'),
(8, 6, 'R005', 'B002', '2024-12-18', '2024-12-20'),
(9, 6, 'R005', 'B002', '2024-12-18', '2024-12-20'),
(10, 6, 'R006', 'B001', '2024-12-18', '2024-12-19'),
(11, 6, 'R006', 'B001', '2024-12-18', '2024-12-25');

-- --------------------------------------------------------

--
-- Table structure for table `room_types`
--

CREATE TABLE `room_types` (
  `Room_Type` varchar(20) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `room_types`
--

INSERT INTO `room_types` (`Room_Type`) VALUES
('Double'),
('Single'),
('Suite');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_ID` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `service_type` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `Price` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_ID`, `service_type`, `Price`) VALUES
('S001', 'Full Body Massage', 80),
('S002', 'Aromatherapy Spa Session', 120),
('S003', 'Gym', 60),
('S004', 'Yoga Class', 30),
('S005', 'Pool', 40),
('S006', 'Sauna Session', 25),
('S007', 'Manicure', 35),
('S008', 'Pedicure', 40),
('S009', 'Guided Tour', 75),
('S010', 'Conference Room', 75);

-- --------------------------------------------------------

--
-- Table structure for table `service_booking`
--

CREATE TABLE `service_booking` (
  `service_booking_ID` int NOT NULL,
  `service_ID` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `Branch_ID` varchar(225) COLLATE utf8mb4_general_ci NOT NULL,
  `Customer_ID` int NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_booking`
--

INSERT INTO `service_booking` (`service_booking_ID`, `service_ID`, `Branch_ID`, `Customer_ID`, `appointment_date`, `appointment_time`) VALUES
(11, 'S008', 'B004', 6, '0000-00-00', '00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `sex_lookup`
--

CREATE TABLE `sex_lookup` (
  `Sex` char(1) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sex_lookup`
--

INSERT INTO `sex_lookup` (`Sex`) VALUES
('F'),
('M');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branches`
--
ALTER TABLE `branches`
  ADD PRIMARY KEY (`Branch_ID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_ID`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `pending_booking`
--
ALTER TABLE `pending_booking`
  ADD PRIMARY KEY (`pending_booking_ID`);

--
-- Indexes for table `pending_service`
--
ALTER TABLE `pending_service`
  ADD PRIMARY KEY (`pending_service_ID`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`Room_ID`),
  ADD KEY `Room_Type` (`Room_Type`);

--
-- Indexes for table `room_booking`
--
ALTER TABLE `room_booking`
  ADD PRIMARY KEY (`room_booking_ID`),
  ADD KEY `branches` (`Branch_ID`),
  ADD KEY `customers` (`Customer_ID`),
  ADD KEY `room` (`Room_ID`);

--
-- Indexes for table `room_types`
--
ALTER TABLE `room_types`
  ADD PRIMARY KEY (`Room_Type`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_ID`);

--
-- Indexes for table `service_booking`
--
ALTER TABLE `service_booking`
  ADD PRIMARY KEY (`service_booking_ID`),
  ADD KEY `branch` (`Branch_ID`),
  ADD KEY `customer` (`Customer_ID`),
  ADD KEY `service` (`service_ID`) USING BTREE;

--
-- Indexes for table `sex_lookup`
--
ALTER TABLE `sex_lookup`
  ADD PRIMARY KEY (`Sex`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `pending_booking`
--
ALTER TABLE `pending_booking`
  MODIFY `pending_booking_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `pending_service`
--
ALTER TABLE `pending_service`
  MODIFY `pending_service_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `room_booking`
--
ALTER TABLE `room_booking`
  MODIFY `room_booking_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `service_booking`
--
ALTER TABLE `service_booking`
  MODIFY `service_booking_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `room_ibfk_1` FOREIGN KEY (`Room_Type`) REFERENCES `room_types` (`Room_Type`);

--
-- Constraints for table `room_booking`
--
ALTER TABLE `room_booking`
  ADD CONSTRAINT `branches` FOREIGN KEY (`Branch_ID`) REFERENCES `branches` (`Branch_ID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `customers` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `room` FOREIGN KEY (`Room_ID`) REFERENCES `room` (`Room_ID`) ON UPDATE CASCADE;

--
-- Constraints for table `service_booking`
--
ALTER TABLE `service_booking`
  ADD CONSTRAINT `branch` FOREIGN KEY (`Branch_ID`) REFERENCES `branches` (`Branch_ID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `customer` FOREIGN KEY (`Customer_ID`) REFERENCES `customer` (`Customer_ID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `service` FOREIGN KEY (`service_ID`) REFERENCES `services` (`service_ID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
