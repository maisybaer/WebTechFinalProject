<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../db/api.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Customer_ID = isset($_SESSION['Customer_ID']) ? $_SESSION['Customer_ID'] : null;
    if (!$Customer_ID) {
        echo "<script>alert('You must be logged in to make a booking.');</script>";
        header("Location: ../view/Login.php");
        exit;
    }

    $Branch_ID = isset($_POST['Branch_ID']) ? trim($_POST['Branch_ID']) : '';
    $Room_ID = isset($_POST['Room_ID']) ? trim($_POST['Room_ID']) : '';
    $Check_In_Date = isset($_POST['Check_In_Date']) ? trim($_POST['Check_In_Date']) : '';
    $Check_Out_Date = isset($_POST['Check_Out_Date']) ? trim($_POST['Check_Out_Date']) : '';
    $Price = "SELECT Price FROM room WHERE Room_ID = ?";
    $Availability= "SELECT Room_Status FROM room WHERE Room_ID = ?";

    $stmtPrice = $conn->prepare($Price);
    $stmtPrice->bind_param("s", $Room_ID);
    $stmtPrice->execute();
    $stmtPrice->bind_result($Price);
    $stmtPrice->fetch();
    $stmtPrice->close();

    $stmtAvailability = $conn->prepare($Availability);
    $stmtAvailability->bind_param("s", $Room_ID);
    $stmtAvailability->execute();
    $stmtAvailability->bind_result($Room_Status);
    $stmtAvailability->fetch();
    $stmtAvailability->close();

    if ($Room_Status > 0) {
        $stmtInsert = $conn->prepare("INSERT INTO pending_booking (Customer_ID, Branch_ID, Room_ID, Price, Check_In_Date, Check_Out_Date) VALUES (?, ?, ?, ?, ?, ?)");
        $stmtInsert->bind_param("isssss", $Customer_ID, $Branch_ID, $Room_ID, $Price, $Check_In_Date, $Check_Out_Date);
        
        if ($stmtInsert->execute()) {
            $stmtUpdate = $conn->prepare("UPDATE room SET Room_Status = Room_Status - 1 WHERE Room_ID = ?");
            $stmtUpdate->bind_param("s", $Room_ID);
            if ($stmtUpdate->execute()) {
                header("Location: ../view/Checkout.php");
                exit;
            } else {
                echo "<script>alert('An error occurred while updating room status.');</script>";
            }
        } else {
            echo "<script>alert('An error occurred. Please try again.');</script>";
        }
    
        $stmtInsert->close();
        $stmtUpdate->close();
    } else {
        echo "<script>alert('Sorry, this room is fully booked.');</script>";
    }    

    $conn->close();
}
?>
