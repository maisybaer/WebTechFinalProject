<?php
require '../db/api.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $First_Name = isset($_POST['First_Name']) ? trim($_POST['First_Name']) : '';
    $Last_Name = isset($_POST['Last_Name']) ? trim($_POST['Last_Name']) : '';
    $Email = isset($_POST['Email']) ? trim($_POST['Email']) : '';
    $Sex = isset($_POST['Sex']) ? trim($_POST['Sex']) : '';
    $DOB = isset($_POST['DOB']) ? trim($_POST['DOB']) : '';
    $Phone_Number = isset($_POST['Phone_Number']) ? trim($_POST['Phone_Number']) : '';
    $pword = isset($_POST['pword']) ? trim($_POST['pword']) : '';

    // Validate inputs
    if (empty($First_Name) || empty($Last_Name) || empty($Email) || empty($pword)) {
        echo '<script>alert("Please fill in all required fields.")</script>';
        header("Location: ../view/Signup.html");
        exit();
    }

    if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {
        echo '<script>alert("Invalid email format.")</script>';
        header("Location: ../view/Signup.html");
        exit();
    }

    $stmt = $conn->prepare('SELECT Email FROM customer WHERE Email = ?');
    $stmt->bind_param('s', $Email);
    $stmt->execute();
    $results = $stmt->get_result();

    if ($results->num_rows > 0) {
        echo '<script>alert("A user with this email already exists.")</script>';
        header("Location: ../view/Signup.html");
        exit();
    } else {
        // Hash the password
        $hashedPassword = password_hash($pword, PASSWORD_DEFAULT);

        // Insert user into the database
        $stmt = $conn->prepare('INSERT INTO customer (First_Name, Last_Name, Email, Sex, DOB, Phone_Number, pword) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->bind_param('sssssss', $First_Name, $Last_Name, $Email, $Sex, $DOB, $Phone_Number, $pword);

        if ($stmt->execute()) {
            header("Location: ../view/Login.php");
            exit();
        } else {
            echo '<script>alert("Error during sign up, please try again.")</script>';
            header("Location: ../view/Signup.html");
            exit();
        }
    }

    $stmt->close();
    $conn->close();
    exit();
}
?>



