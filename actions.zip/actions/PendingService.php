<?php
include '../db/api.php';
session_start();


error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Customer_ID = isset($_SESSION['Customer_ID']) ? $_SESSION['Customer_ID'] : null;
    if (!$Customer_ID) {
        echo "<script>alert('You must be logged in to make a booking.');</script>";
        header("Location: ../view/Login.php");
        exit;
    }

    $Branch_ID = isset($_POST['Branch_ID']) ? trim($_POST['Branch_ID']) : '';
    $service_ID = isset($_POST['service_ID']) ? trim($_POST['service_ID']) : '';
    $Appointment_Date = isset($_POST['appointment_date']) ? trim($_POST['appointment_date']) : '';
    $Appointment_Time = isset($_POST['appointment_time']) ? trim($_POST['appointment_time']) : '';

    $Branch_Location_Query = "SELECT Branch_Location FROM branches WHERE Branch_ID = ?";
    $stmtBranch = $conn->prepare($Branch_Location_Query);
    $stmtBranch->bind_param("s", $Branch_ID);
    $stmtBranch->execute();
    $stmtBranch->bind_result($Branch_Location);
    $stmtBranch->fetch();
    $stmtBranch->close();

    $Price_Query = "SELECT Price FROM services WHERE service_ID = ?";
    $stmtPrice = $conn->prepare($Price_Query);
    $stmtPrice->bind_param("s", $service_ID);
    $stmtPrice->execute();
    $stmtPrice->bind_result($Price);
    $stmtPrice->fetch();
    $stmtPrice->close();

    $Service_Name_Query = "SELECT service_type FROM services WHERE service_ID = ?";
    $stmtService = $conn->prepare($Service_Name_Query);
    $stmtService->bind_param("s", $service_ID);
    $stmtService->execute();
    $stmtService->bind_result($service_Name);
    $stmtService->fetch();
    $stmtService->close();

    $Insert_Query = "INSERT INTO pending_service (Customer_ID, Branch_ID, Branch_Location, service_ID, service_type, Price, appointment_date, appointment_time) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmtInsert = $conn->prepare($Insert_Query);
    $stmtInsert->bind_param("isssssss", $Customer_ID, $Branch_ID, $Branch_Location, $service_ID, $service_Name, $Price, $Appointment_Date, $Appointment_Time);

    if ($stmtInsert->execute()) {
        header("Location: ../view/ServiceCheckout.php");
        exit;
    } else {
        echo "Error: " . $stmtInsert->error;
    }

    $stmtInsert->close();
    $conn->close();
}
?>

