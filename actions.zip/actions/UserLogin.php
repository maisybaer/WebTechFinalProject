<?php
session_start();

require '../db/api.php';


    $Email = htmlspecialchars(trim($_POST['Email']));
    $pword = trim($_POST['pword']);

    $sql = "SELECT * FROM customer WHERE Email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $Email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        if ($pword===$row['pword']) {
            $_SESSION['Email'] = $Email;
            $_SESSION['Customer_ID'] = $row['Customer_ID'];
            $_SESSION['Name'] = $row['First_Name']." ".$row['Last_Name'];
            header("Location: ../view/Booking.php");
            exit();
        } else {
            echo "Invalid username or password!";
        }
    } else {
        echo "User not found!";
    }

    $stmt->close();
    $conn->close();
?>


