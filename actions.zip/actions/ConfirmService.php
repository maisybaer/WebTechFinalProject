<?php
include '../db/api.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Customer_ID = isset($_SESSION['Customer_ID']) ? $_SESSION['Customer_ID'] : null;

    if (!$Customer_ID) {
        die("Error: Customer is not logged in.");
    }

    // Fetch pending bookings
    $sql = "SELECT service_ID, Branch_ID, appointment_date, appointment_time FROM pending_service WHERE Customer_ID = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i", $Customer_ID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $insertStmt = $conn->prepare(
                "INSERT INTO service_booking (Customer_ID, service_ID, Branch_ID, appointment_date, appointment_time) 
                 VALUES (?, ?, ?, ?, ?)"
            );
            if (!$insertStmt) {
                die("Failed to prepare insert statement: " . $conn->error);
            }

            while ($row = $result->fetch_assoc()) {
                $service_ID = $row['service_ID'];
                $Branch_ID = $row['Branch_ID'];
                $appointment_date = $row['appointment_date'];
                $appointment_time = $row['appointment_time'];

                $insertStmt->bind_param("issss", $Customer_ID, $service_ID, $Branch_ID, $appointment_date, $appointment_time);
                if (!$insertStmt->execute()) {
                    die("Error inserting booking: " . $insertStmt->error);
                }
            }

            $insertStmt->close();
        } else {
            die("No pending bookings found for the customer.");
        }

        $stmt->close();
    } else {
        die("Failed to prepare select statement: " . $conn->error);
    }

    // Clear pending bookings
    $clearBasketSQL = "DELETE FROM pending_service WHERE Customer_ID = ?";
    $clearStmt = $conn->prepare($clearBasketSQL);
    if ($clearStmt) {
        $clearStmt->bind_param("i", $Customer_ID);
        if (!$clearStmt->execute()) {
            die("Error clearing pending bookings: " . $clearStmt->error);
        }
        $clearStmt->close();
    } else {
        die("Failed to prepare clear statement: " . $conn->error);
    }
}

$conn->close();
header("Location: ../view/ThankYou.php");
exit();
?>
