<?php
include '../db/api.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Customer_ID = isset($_SESSION['Customer_ID']) ? $_SESSION['Customer_ID'] : null;

    if (!$Customer_ID) {
        die("Error: Customer is not logged in.");
    }

    // Fetch pending bookings
    $sql = "SELECT Room_ID, Branch_ID, Check_In_Date, Check_Out_Date FROM pending_booking WHERE Customer_ID = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i", $Customer_ID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $insertStmt = $conn->prepare(
                "INSERT INTO room_booking (Customer_ID, Room_ID, Branch_ID, Check_In_Date, Check_Out_Date) 
                 VALUES (?, ?, ?, ?, ?)"
            );
            if (!$insertStmt) {
                die("Failed to prepare insert statement: " . $conn->error);
            }

            while ($row = $result->fetch_assoc()) {
                $Room_ID = $row['Room_ID'];
                $Branch_ID = $row['Branch_ID'];
                $Check_In_Date = $row['Check_In_Date'];
                $Check_Out_Date = $row['Check_Out_Date'];

                // Debugging
                error_log("Room_ID: $Room_ID, Branch_ID: $Branch_ID, Check_In_Date: $Check_In_Date, Check_Out_Date: $Check_Out_Date");

                if (empty($Room_ID)) {
                    die("Error: Room_ID is empty or null.");
                }

                $insertStmt->bind_param("issss", $Customer_ID, $Room_ID, $Branch_ID, $Check_In_Date, $Check_Out_Date);
                if (!$insertStmt->execute()) {
                    die("Error inserting booking: " . $insertStmt->error);
                }
            }

            $insertStmt->close();
        } else {
            die("No pending bookings found for the customer.");
        }

        $stmt->close();
    } else {
        die("Failed to prepare select statement: " . $conn->error);
    }

    // Clear pending bookings
    $clearBasketSQL = "DELETE FROM pending_booking WHERE Customer_ID = ?";
    $clearStmt = $conn->prepare($clearBasketSQL);
    if ($clearStmt) {
        $clearStmt->bind_param("i", $Customer_ID);
        if (!$clearStmt->execute()) {
            die("Error clearing pending bookings: " . $clearStmt->error);
        }
        $clearStmt->close();
    } else {
        die("Failed to prepare clear statement: " . $conn->error);
    }
}

$conn->close();
header("Location: ../view/ThankYou.php");
exit();
?>
