<?php
session_start();
require "../db/api.php";

$Customer_ID = isset($_SESSION['Customer_ID']) ? $_SESSION['Customer_ID'] : null;
if (!$Customer_ID) {
    echo "<script>alert('You must be logged in to see your bookings.');</script>";
    header("Location: ../view/Login.php");
    exit;
}

function fetchBooking($conn) {
    global $Customer_ID;
    $query = "SELECT rb.*, b.Branch_Location, r.Room_Name, r.Price, rb.Check_In_Date, rb.Check_Out_Date, c.First_Name, c.Last_Name
              FROM room_booking rb
              LEFT JOIN branches b ON rb.Branch_ID = b.Branch_ID
              LEFT JOIN room r ON rb.Room_ID = r.Room_ID
            LEFT JOIN customer c ON rb.Customer_ID = c.Customer_ID
              WHERE rb.Customer_ID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $Customer_ID);
    $stmt->execute();
    $result = $stmt->get_result();
    $bookings = [];
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
    $stmt->close();
    return $bookings;
}

function fetchServiceBooking($conn) {
    global $Customer_ID;
    $query = "SELECT sb.*, b.Branch_Location, s.service_type, sb.appointment_date, sb.appointment_time, c.First_Name, c.Last_Name, s.Price
              FROM service_booking sb
              LEFT JOIN branches b ON sb.Branch_ID = b.Branch_ID
              LEFT JOIN services s ON sb.service_ID = s.service_ID
            LEFT JOIN customer c ON sb.Customer_ID = c.Customer_ID
              WHERE sb.Customer_ID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $Customer_ID);
    $stmt->execute();
    $result = $stmt->get_result();
    $service_bookings = [];
    while ($row = $result->fetch_assoc()) {
        $service_bookings[] = $row;
    }
    $stmt->close();
    return $service_bookings;
}

$bookings = fetchBooking($conn);
$service_bookings = fetchServiceBooking($conn);

// Room Bookings - Edit
if (isset($_POST['room-edit-btn'])) {
    $room_booking_ID = $_POST['room_booking_ID'];
    $Branch_ID = $_POST['Branch_ID'];
    $Room_ID = $_POST['Room_ID'];
    $Check_In_Date = $_POST['Check_In_Date'];
    $Check_Out_Date = $_POST['Check_Out_Date'];

    $updateSQL = "UPDATE room_booking SET Branch_ID = ?, Room_ID = ?, Check_In_Date = ?, Check_Out_Date = ? WHERE room_booking_ID = ?";
    $stmt = $conn->prepare($updateSQL);
    $stmt->bind_param("ssssi", $Branch_ID, $Room_ID, $Check_In_Date, $Check_Out_Date, $room_booking_ID);
    $stmt->execute();
    $stmt->close();

    header("Location: MyBooking.php");
    exit;
}

// Room Bookings - Delete
if (isset($_POST['room-delete-btn'])) {
    $room_booking_ID = $_POST['room_booking_ID'];
    $deleteSQL = "DELETE FROM room_booking WHERE room_booking_ID = ?";
    $stmt = $conn->prepare($deleteSQL);
    $stmt->bind_param("i", $room_booking_ID);
    $stmt->execute();
    $stmt->close();

    header("Location: MyBooking.php");
    exit;
}

// Service Bookings - Edit
if (isset($_POST['service-edit-btn'])) {
    $service_booking_ID = $_POST['service_booking_ID'];
    $Branch_ID = $_POST['Branch_ID'];
    $Service_ID = $_POST['Service_ID'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];

    $updateSQL = "UPDATE service_booking SET Branch_ID = ?, service_ID = ?, appointment_date = ?, appointment_time = ? WHERE service_booking_ID = ?";
    $stmt = $conn->prepare($updateSQL);
    $stmt->bind_param("ssssi", $Branch_ID, $Service_ID, $appointment_date, $appointment_time, $service_booking_ID);
    $stmt->execute();
    $stmt->close();

    header("Location: MyBooking.php");
    exit;
}

// Service Bookings - Delete
if (isset($_POST['service-delete-btn'])) {
    $service_booking_ID = $_POST['service_booking_ID'];
    $deleteSQL = "DELETE FROM service_booking WHERE service_booking_ID = ?";
    $stmt = $conn->prepare($deleteSQL);
    $stmt->bind_param("i", $service_booking_ID);
    $stmt->execute();
    $stmt->close();

    header("Location: MyBooking.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta name='viewport' content="width=device-width inital-scale=1.0">
	<title>My Bookings</title>
	<link rel="icon" type="image/x-icon" href="../assets/favicon/favicon.ico">
	<link rel="stylesheet" href="../assets/css/Booking.css?v.1">
</head>

<body>
    <nav>
        <div class="grid-container-nav">
            <a href="Homepage.html"><div class="grid-item"><img class="logo" src="../assets/images/SammanLogo.png" alt="Samman Resorts Logo" style="width:70px; height:auto; margin:0px"></div></a>
            <a href="Booking.php"><div class="grid-item"><p>Book a room</p></div></a>
            <a href="Service.php"><div class="grid-item"><p>Book a service</p></div></a>
            <a href="MyBooking.php"><div class="grid-item"><p>My Bookings</p></div></a>
            <a href="AdminLogin.html"><div class="grid-item"><p>Admin</p></div></a>
            <a href="../actions/Logout.php"><div class="grid-item"><p>Logout</p></div></a>
        </div>
    </nav>

    <main>

        <div class="large-login-card">
            <h2>Manage your bookings</h2>
            <br>
            <h3 style="text-align=left">Room Bookings</h3>
        
                <table id="inventoryTable">
                    <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th>Branch</th>
                            <th>Room</th>
                            <th>Check In</th>
                            <th>Check Out</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($bookings as $item): ?>
                            <tr>
                                <td>RB<?php echo htmlspecialchars($item['room_booking_ID']); ?></td>
                                <td><?php echo htmlspecialchars($item['Branch_Location']); ?></td>
                                <td><?php echo htmlspecialchars($item['Room_Name']); ?></td>
                                <td><?php echo htmlspecialchars($item['Check_In_Date']); ?></td>
                                <td><?php echo htmlspecialchars($item['Check_Out_Date']); ?></td>
                                <td>

                                <!-- View Details Popup -->
                                <button class="action" onclick="openRoomDetails('<?php echo $item['room_booking_ID']; ?>')">Details</button>
                                <div id="details-popup-<?php echo $item['room_booking_ID']; ?>" class="popup" style="display:none;">
                                    <div class="popup-content" style="text-align:left;">
                                        <input type="hidden" name="room_booking_ID" value="<?php echo htmlspecialchars($item['room_booking_ID']); ?>">
                                        <h1>Booking Details</h1>
                                        <p class="login-subtitle">Branch ID: <?php echo htmlspecialchars($item['Branch_ID']); ?> </p>
                                        <p class="login-subtitle">Room Name: <?php echo htmlspecialchars($item['Room_Name']); ?> </p>
                                        <p class="login-subtitle">Customer Name: <?php echo htmlspecialchars($item['First_Name'] . ' ' . $item['Last_Name']); ?> </p>
                                        <p class="login-subtitle">Price: GHS <?php echo htmlspecialchars($item['Price']); ?> </p>
                                        <button class="white-button" type="button" onclick="closeRoomDetails('<?php echo $item['room_booking_ID']; ?>')">Close</button>
                                    </div>
                                </div>

                                    <!-- Edit Popup -->
                                    <button class="action" onclick="openRoomUpdate('<?php echo $item['room_booking_ID']; ?>')">Edit</button>
                                    
                                    <div id="room-edit-popup-<?php echo $item['room_booking_ID']; ?>" class="popup" style="display:none;">
                                        <form class="popup-content" method="POST" action="">
                                            <h1>Edit Booking</h1>
                                            <input type="hidden" name="room_booking_ID" value="<?php echo htmlspecialchars($item['room_booking_ID']); ?>">
                                            <p class="login-subtitle">Select your location</p>
                                            <select name="Branch_ID" required>
                                                <option value="">Branch</option>
                                                <option value="B001" <?php echo ($item['Branch_ID'] == 'B001' ? 'selected' : ''); ?>>Accra</option>
                                        <option value="B002" <?php echo ($item['Branch_ID'] == 'B002' ? 'selected' : ''); ?>>Koforidua</option>
                                        <option value="B003" <?php echo ($item['Branch_ID'] == 'B003' ? 'selected' : ''); ?>>Kwahu</option>
                                        <option value="B004" <?php echo ($item['Branch_ID'] == 'B004' ? 'selected' : ''); ?>>Kumasi</option>
                                            </select>

                                            <p class="login-subtitle">Select your room</p>
                                            <select name="Room_ID" required>
                                                <option value="">Room Type</option>
                                        <option value="R001" <?php echo ($item['Room_ID'] == 'R001' ? 'selected' : ''); ?>>Deluxe</option>
                                        <option value="R002" <?php echo ($item['Room_ID'] == 'R002' ? 'selected' : ''); ?>>Superior</option>
                                        <option value="R003" <?php echo ($item['Room_ID'] == 'R003' ? 'selected' : ''); ?>>Executive</option>
                                        <option value="R004" <?php echo ($item['Room_ID'] == 'R004' ? 'selected' : ''); ?>>Standard</option>
                                        <option value="R005" <?php echo ($item['Room_ID'] == 'R005' ? 'selected' : ''); ?>>Family</option>
                                        <option value="R006" <?php echo ($item['Room_ID'] == 'R006' ? 'selected' : ''); ?>>Junior</option>
                                        <option value="R007" <?php echo ($item['Room_ID'] == 'R007' ? 'selected' : ''); ?>>Economy</option>
                                            </select>

                                            <p class="login-subtitle">Check in date</p>
                                            <input type="date" name="Check_In_Date" required>

                                            <p class="login-subtitle">Check out date</p>
                                            <input type="date" name="Check_Out_Date" required>

                                            <button type="submit" name="room-edit-popup-<?php echo $item['room_booking_ID']; ?>">Update</button>
                                            <button class="white-button" type="button" onclick="closeRoomUpdate('<?php echo $item['room_booking_ID']; ?>')">Cancel</button>
                                        </form>
                                    </div>

                                    <!-- Delete Popup -->
                                    <button class="action" onclick="openRoomDelete('<?php echo $item['room_booking_ID']; ?>')">Delete</button>
                                  
                                    <div id="delete-popup-<?php echo $item['room_booking_ID']; ?>" class="popup" style="display:none;">
                                        <form class="popup-content" method="POST" action="">
                                            <input type="hidden" name="room_booking_ID" value="<?php echo htmlspecialchars($item['room_booking_ID']); ?>">
                                            <h1>Delete Booking</h1>
                                            <p>Are you sure you want to delete this booking?</p>
                                            <br>
                                            <button type="submit" name="room-delete-btn" class="room-delete-btn">Delete</button>
                                            <button class="white-button" type="button" onclick="closeRoomDelete('<?php echo $item['room_booking_ID']; ?>')">Cancel</button>
                                        </form>
                                    </div>
                                </td>  
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
        

            <br>
            <h3>Service bookings</h3>

            
            <table id="inventoryTable">
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>Branch</th>
                        <th>Service Name</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($service_bookings as $item): ?>
                        <tr>
                            <td>SB<?php echo htmlspecialchars($item[ 'service_booking_ID']); ?></td>
                            <td><?php echo htmlspecialchars($item['Branch_Location']); ?></td>
                            <td><?php echo htmlspecialchars($item['service_type']); ?></td>
                            <td><?php echo htmlspecialchars($item['appointment_date']); ?></td>
                            <td><?php echo htmlspecialchars($item['appointment_time']); ?></td>
                            <td>

                            <!--Details Popup-->
                            <button class="action" onclick="openServiceDetails('<?php echo $item['service_booking_ID']; ?>')">Details</button>
                            <div id="details-popup-<?php echo $item['service_booking_ID']; ?>" class="popup" style="display:none;">
                                    <div class="popup-content" style="text-align:left;">
                                    <input type="hidden" name="service_booking_ID" value="<?php echo htmlspecialchars($item['service_booking_ID']); ?>">
                                    <h1>Booking Details</h1>
                                    <p class="login-subtitle">Branch ID: <?php echo htmlspecialchars($item['Branch_ID']); ?> </p>
                                    <p class="login-subtitle">Service ID: <?php echo htmlspecialchars($item['service_ID']); ?> </p>
                                    <p class="login-subtitle">Customer Name: <?php echo htmlspecialchars($item['First_Name'].$item['Last_Name']); ?> </p>
                                    <p class="login-subtitle">Price: GHS<?php echo htmlspecialchars($item['Price']); ?> </p>
                                    <button class="white-button" type="button" onclick="closeServiceDetails('<?php echo $item['service_booking_ID']; ?>')">Close</button>
                                     </div>
                            </div>
                                <!-- Edit Popup -->
                                <button class="action" onclick="openServiceUpdate('<?php echo $item['service_booking_ID']; ?>')">Edit</button>
                                <div id="service-edit-popup-<?php echo $item['service_booking_ID']; ?>" class="popup" style="display:none;">
                                
                                <form class="popup-content" method="POST" action="">
                                        <h1>Edit Service Booking</h1>
                                    
                                        <input type="hidden" name="service_booking_ID" value="<?php echo htmlspecialchars($item['service_booking_ID']); ?>">
                                        <p class="login-subtitle">Select your location</p>
                                        <select id="Branch_ID" name="Branch_ID">
                                            <option value="">Branch</option>
                                        <option value="B001" <?php echo ($item['Branch_ID'] == 'B001' ? 'selected' : ''); ?>>Accra</option>
                                        <option value="B002" <?php echo ($item['Branch_ID'] == 'B002' ? 'selected' : ''); ?>>Koforidua</option>
                                        <option value="B003" <?php echo ($item['Branch_ID'] == 'B003' ? 'selected' : ''); ?>>Kwahu</option>
                                        <option value="B004" <?php echo ($item['Branch_ID'] == 'B004' ? 'selected' : ''); ?>>Kumasi</option>
                                        </select>

                                        <p class="login-subtitle">Select your service</p>
                                        <select id="Service_ID" name="Service_ID">
                                        <option value="S001" <?php echo ($item['service_ID'] == 'S001' ? 'selected' : ''); ?>>Full Body Massage</option>
                                        <option value="S002" <?php echo ($item['service_ID'] == 'S002' ? 'selected' : ''); ?>>Aromatherapy Spa Session</option>
                                        <option value="S003" <?php echo ($item['service_ID'] == 'S003' ? 'selected' : ''); ?>>Gym</option>
                                        <option value="S004" <?php echo ($item['service_ID'] == 'S004' ? 'selected' : ''); ?>>Yoga Class</option>
                                        <option value="S005" <?php echo ($item['service_ID'] == 'S005' ? 'selected' : ''); ?>>Pool</option>
                                        <option value="S006" <?php echo ($item['service_ID'] == 'S006' ? 'selected' : ''); ?>>Sauna Session</option>
                                        <option value="S007" <?php echo ($item['service_ID'] == 'S007' ? 'selected' : ''); ?>>Manicure</option>
                                        <option value="S008" <?php echo ($item['service_ID'] == 'S008' ? 'selected' : ''); ?>>Pedicure</option>
                                        <option value="S009" <?php echo ($item['service_ID'] == 'S009' ? 'selected' : ''); ?>>Guided Tour</option>
                                        <option value="S0010" <?php echo ($item['service_ID'] == 'S0010' ? 'selected' : ''); ?>>Conference Room</option>
                                        </select>

                                        <p class="login-subtitle">Book your dates</p>
                                        
                                        <p class="plain">Appointment Date<p>
                                        <input type="date" class="input" id="appointment_date" required>

                                        <p class="plain">Appointment Time<p>
                                        <input type="time" class="input" id="appointment_time" required>

                                        <button type="submit" name="service-edit-btn">Update</button>
                                        <button class="white-button" type="button" onclick="closeServiceUpdate('<?php echo $item['service_booking_ID']; ?>')">Cancel</button>
                                    </form>
                                </div>

                                <!-- Delete Popup -->
                                <button class="action" onclick="openServiceDelete('<?php echo $item['service_booking_ID']; ?>')">Delete</button>
                                <div id="delete-popup-<?php echo $item['service_booking_ID']; ?>" class="popup" style="display:none;">
                                    <form class="popup-content" method="POST" action="">
                                        <input type="hidden" name="service_booking_ID" value="<?php echo htmlspecialchars($item['service_booking_ID']); ?>">
                                        <h1>Delete Booking</h1>
                                        <p>Are you sure you want to delete this booking?</p>
                                        <br>
                                        <button type="submit" name="service-delete-btn" class="delete-btn">Delete</button>
                                        <button class="white-button" type="button" onclick="closeServiceDelete('<?php echo $item['service_booking_ID']; ?>')">Cancel</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>


            
        </div>

    </main>

</body>

<script>
//ROOM Buttons
function openRoomUpdate(id) {
    document.getElementById('room-edit-popup-' + id).style.display = 'block';
}
function closeRoomUpdate(id) {
    document.getElementById('room-edit-popup-' + id).style.display = 'none';
}

function openRoomDelete(id) {
    document.getElementById('room-delete-popup-' + id).style.display = 'block';
}
function closeRoomDelete(id) {
    document.getElementById('room-delete-popup-' + id).style.display = 'none';
}  

function openRoomDetails(id) {
    document.getElementById('details-popup-' + id).style.display = 'block';
}
function closeRoomDetails(id) {
    document.getElementById('details-popup-' + id).style.display = 'none';
}

//Service Buttons
function openServiceUpdate(id) {
    document.getElementById('service-edit-popup-' + id).style.display = 'block';
}
function closeServiceUpdate(id) {
    document.getElementById('service-edit-popup-' + id).style.display = 'none';
}

function openServiceDelete(id) {
    document.getElementById('service-delete-popup-' + id).style.display = 'block';
}
function closeServiceDelete(id) {
    document.getElementById('service-delete-popup-' + id).style.display = 'none';
}

function openServiceDetails(id) {
    document.getElementById('details-popup-' + id).style.display = 'block';
}
function closeServiceDetails(id) {
    document.getElementById('details-popup-' + id).style.display = 'none';
}


</script>

</html>