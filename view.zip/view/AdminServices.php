<?php
session_start();
require "../db/api.php";


// Fetch bookings
function fetchBooking($conn) {
    $query = "SELECT sb.*, c.First_Name, c.Last_Name, b.Branch_Location, s.service_type, s.Price
              FROM service_booking sb
              LEFT JOIN customer c ON sb.Customer_ID = c.Customer_ID
              LEFT JOIN branches b ON sb.Branch_ID = b.Branch_ID
              LEFT JOIN services s ON sb.service_ID = s.service_ID";
    $result = $conn->query($query);
    $service_bookings = [];
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $service_bookings[] = $row;
        }
        $result->free();
    } else {
        echo "Error fetching bookings: " . $conn->error;
    }
    
    return $service_bookings;
}

$service_bookings = fetchBooking($conn);

// Update service booking
if (isset($_POST['edit-btn'])) {
    $service_booking_ID = $_POST['service_booking_ID'];
    $Branch_ID = $_POST['Branch_ID'];
    $service_ID = $_POST['service_ID'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = $_POST['appointment_time'];

    $updateSQL = "UPDATE service_booking SET Branch_ID=?, service_ID=?, appointment_date=?, appointment_time=? WHERE service_booking_ID=?";
    $stmt = $conn->prepare($updateSQL);
    if ($stmt) {
        $stmt->bind_param("ssssi", $Branch_ID, $service_ID, $appointment_date, $appointment_time, $service_booking_ID);
        if (!$stmt->execute()) {
            echo "Error updating booking: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    header("Location: AdminServices.php");
    exit;
}

// Delete booking
if (isset($_POST['delete-btn'])) {
    $service_booking_ID = $_POST['service_booking_ID'];

    $deleteSQL = "DELETE FROM service_booking WHERE service_booking_ID=?";
    $stmt = $conn->prepare($deleteSQL);
    if ($stmt) {
        $stmt->bind_param("i", $service_booking_ID);
        if (!$stmt->execute()) {
            echo "Error deleting booking: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    header("Location: AdminServices.php");
    exit;
}
?>


<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Bookings</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon/favicon.ico">
    <link rel="stylesheet" href="../assets/css/AdminDashboard.css?v.1">
</head>
<body>
<div class="page-grid-container">
    <div name="menu" class="item2">
        <a href="Homepage.html"><img class="logo" src="../assets/images/SammanLogo.png" alt="Samman Resorts Logo" style="width:100px; height:auto;"></a>
        <p id="title">Menu</p>
        <a href="AdminBooking.php"><div class="grid-item"><p>Booking</p></div></a>
        <a href="AdminServices.php"><div class="grid-item"><p>Services</p></div></a>
        <a href="../actions/Logout.php"><div class="grid-item"><p>Logout</p></div></a>
    </div>

    <div name="header" class="item1">
        <h1>Service Bookings</h1>
        <p>Manage your bookings</p>
    </div>

    <div name="main" class="item3">
        <table id="inventoryTable">
            <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Branch</th>
                    <th>Service Name</th>
                    <th>Customer ID</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($service_bookings as $item): ?>
                    <tr>
                        <td>RB<?php echo htmlspecialchars($item['service_booking_ID']); ?></td>
                        <td><?php echo htmlspecialchars($item['Branch_Location']); ?></td>
                        <td><?php echo htmlspecialchars($item['service_type']); ?></td>
                        <td>C<?php echo htmlspecialchars($item['Customer_ID']); ?></td>
                        <td><?php echo htmlspecialchars($item['appointment_date']); ?></td>
                        <td><?php echo htmlspecialchars($item['appointment_time']); ?></td>
                        <td>

                            <!--Details Popup-->
                            <button class="action" onclick="openDetails('<?php echo $item['service_booking_ID']; ?>')">Details</button>
                            <div id="details-popup-<?php echo $item['service_booking_ID']; ?>" class="popup" style="display:none;">
                                    <div class="popup-content" style="text-align:left;">
                                    <input type="hidden" name="service_booking_ID" value="<?php echo htmlspecialchars($item['service_booking_ID']); ?>">
                                    <h1>Booking Details</h1>
                                    <p class="login-subtitle">Branch ID: <?php echo htmlspecialchars($item['Branch_ID']); ?> </p>
                                    <p class="login-subtitle">Service ID: <?php echo htmlspecialchars($item['service_ID']); ?> </p>
                                    <p class="login-subtitle">Customer Name: <?php echo htmlspecialchars($item['First_Name'].$item['Last_Name']); ?> </p>
                                    <p class="login-subtitle">Price: GHS<?php echo htmlspecialchars($item['Price']); ?> </p>
                                    <button class="white-button" type="button" onclick="closeDetails('<?php echo $item['service_booking_ID']; ?>')">Close</button>
                                     </div>
                            </div>


                            <!-- Edit Popup -->
                            <button class="action" onclick="openUpdate('<?php echo $item['service_booking_ID']; ?>')">Edit</button>
                            <div id="edit-popup-<?php echo $item['service_booking_ID']; ?>" class="popup" style="display:none;">
                                <form class="popup-content" method="POST" action="">
                                    <h1>Edit Service Booking</h1>
                                    <input type="hidden" name="service_booking_ID" value="<?php echo htmlspecialchars($item['service_booking_ID']); ?>">
                                    
                                    <p class="login-subtitle">Select your location</p>
                                    <select id="Branch_ID" name="Branch_ID">
                                        <option value="B001" <?php echo ($item['Branch_ID'] == 'B001' ? 'selected' : ''); ?>>Accra</option>
                                        <option value="B002" <?php echo ($item['Branch_ID'] == 'B002' ? 'selected' : ''); ?>>Koforidua</option>
                                        <option value="B003" <?php echo ($item['Branch_ID'] == 'B003' ? 'selected' : ''); ?>>Kwahu</option>
                                        <option value="B004" <?php echo ($item['Branch_ID'] == 'B004' ? 'selected' : ''); ?>>Kumasi</option>
                                    </select>

                                    <p class="login-subtitle">Select your service</p>
                                    <select id="service_ID" name="service_ID">
                                        <option value="S001" <?php echo ($item['service_ID'] == 'S001' ? 'selected' : ''); ?>>Full Body Massage</option>
                                        <option value="S002" <?php echo ($item['service_ID'] == 'S002' ? 'selected' : ''); ?>>Aromatherapy Spa Session</option>
                                        <option value="S003" <?php echo ($item['service_ID'] == 'S003' ? 'selected' : ''); ?>>Gym</option>
                                        <option value="S004" <?php echo ($item['service_ID'] == 'S004' ? 'selected' : ''); ?>>Yoga Class</option>
                                        <option value="S005" <?php echo ($item['service_ID'] == 'S005' ? 'selected' : ''); ?>>Pool</option>
                                        <option value="S006" <?php echo ($item['service_ID'] == 'S006' ? 'selected' : ''); ?>>Sauna Session</option>
                                        <option value="S007" <?php echo ($item['service_ID'] == 'S007' ? 'selected' : ''); ?>>Manicure</option>
                                        <option value="S008" <?php echo ($item['service_ID'] == 'S008' ? 'selected' : ''); ?>>Pedicure</option>
                                        <option value="S009" <?php echo ($item['service_ID'] == 'S009' ? 'selected' : ''); ?>>Guided Tour</option>
                                        <option value="S0010" <?php echo ($item['service_ID'] == 'S0010' ? 'selected' : ''); ?>>Conference Room</option>

                                    </select>

                                    <p class="login-subtitle">Appointment Date</p>
                                    <input type="date" class="input" id="appointment_date" name="appointment_date" value="<?php echo htmlspecialchars($item['appointment_date']); ?>" required>

                                    <p class="login-subtitle">Appointment Time</p>
                                    <input type="time" class="input" id="appointment_time" name="appointment_time" value="<?php echo htmlspecialchars($item['appointment_time']); ?>" required>

                                    <button type="submit" name="edit-btn">Update</button>
                                    <button class="white-button" type="button" onclick="closeUpdate('<?php echo $item['service_booking_ID']; ?>')">Cancel</button>
                                </form>
                            </div>

                            <!-- Delete Popup -->
                            <button class="action" onclick="openDelete('<?php echo $item['service_booking_ID']; ?>')">Delete</button>
                            <div id="delete-popup-<?php echo $item['service_booking_ID']; ?>" class="popup" style="display:none;">
                                <form class="popup-content" method="POST" action="">
                                    <input type="hidden" name="service_booking_ID" value="<?php echo htmlspecialchars($item['service_booking_ID']); ?>">
                                    <h1>Delete Booking</h1>
                                    <p>Are you sure you want to delete this booking?</p>
                                    <br>
                                    <button type="submit" name="delete-btn" class="delete-btn">Delete</button>
                                    <button class="white-button" type="button" onclick="closeDelete('<?php echo $item['service_booking_ID']; ?>')">Cancel</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
// Update Popup
function openUpdate(id) {
    document.getElementById('edit-popup-' + id).style.display = 'block';
}
function closeUpdate(id) {
    document.getElementById('edit-popup-' + id).style.display = 'none';
}

// Delete Popup
function openDelete(id) {
    document.getElementById('delete-popup-' + id).style.display = 'block';
}
function closeDelete(id) {
    document.getElementById('delete-popup-' + id).style.display = 'none';
}

//Details Popup
function openDetails(id) {
    document.getElementById('details-popup-' + id).style.display = 'block';
}
function closeDetails(id) {
    document.getElementById('details-popup-' + id).style.display = 'none';
}
</script>
</body>
</html>
