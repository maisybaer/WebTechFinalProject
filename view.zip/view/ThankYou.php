<?php
session_start();


?>

<!DOCTYPE html>
<html>
<head>
	<meta name='viewport' content="width=device-width inital-scale=1.0">
	<title>Thank You</title>
	<link rel="icon" type="image/x-icon" href="..assets/favicon/favicon.ico">
	<link rel="stylesheet" href="../assets/css/Booking.css?v.1">
</head>

<body>
    <nav>
        <div class="grid-container-nav">
            <a href="Homepage.html"><div class="grid-item"><img class="logo" src="../assets/images/SammanLogo.png" alt="Samman Resorts Logo" style="width:70px; height:auto; margin:0px"></div></a>
            <a href="Booking.php"><div class="grid-item"><p>Book a room</p></div></a>
            <a href="Service.php"><div class="grid-item"><p>Book a service</p></div></a>
            <a href="MyBooking.php"><div class="grid-item"><p>My Bookings</p></div></a>
            <a href="AdminLogin.html"><div class="grid-item"><p>Admin</p></div></a>
        </div>
    </nav>

    <main>
        <div class="login-card">
            <h2>Thank you <?php echo  $_SESSION['Name']?> for your booking</h2>

            <br>
            <p>Where to next?</p><br>

            <a href="Service.php"><button>Book a service</button></a>
            <a href="MyBooking.php"><button>My Bookings</button></a>
        </div>
    </main>

</body>
</html>