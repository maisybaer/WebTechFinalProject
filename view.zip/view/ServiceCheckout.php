<?php
session_start();
include '../db/api.php';


$sql = "SELECT * FROM pending_service";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $service_type = $row['service_type']?? 'N/A';
        $Branch_Location= $row['Branch_Location']?? 'N/A';
        $appointment_date = $row['appointment_date'] ?? 'N/A';
        $appointment_time= $row['appointment_time']?? 'N/A';
        $Price = $row['Price']?? 'N/A';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta name='viewport' content="width=device-width inital-scale=1.0">
	<title>Checkout</title>
	<link rel="icon" type="image/x-icon" href="../assets/favicon/favicon.ico">
	<link rel="stylesheet" href="../assets/css/Booking.css?v.1">
</head>

<body>
    <nav>
    <div class="grid-container-nav">
            <a href="Homepage.html"><div class="grid-item"><img class="logo" src="../assets/images/SammanLogo.png" alt="Samman Resorts Logo" style="width:70px; height:auto; margin:0px"></div></a>
            <a href="Booking.php"><div class="grid-item"><p>Book a room</p></div></a>
            <a href="Service.php"><div class="grid-item"><p>Book a service</p></div></a>
            <a href="MyBooking.php"><div class="grid-item"><p>My Bookings</p></div></a>
            <a href="AdminLogin.html"><div class="grid-item"><p>Admin</p></div></a>
        </div>
    </nav>

    <main>

        <div class="login-card">
            <h1>Your Booking</h1>
            <p class="login-subtitle"  style="text-align:left; margin-bottom:0;">Service: <?php echo  $service_type?></p>
            <p class="login-subtitle"  style="text-align:left; margin-bottom:0;">Location: <?php echo  $Branch_Location?></p>
            <p class="login-subtitle"  style="text-align:left; margin-bottom:0;">Appointment Date: <?php echo  $appointment_date ?></p>
            <p class="login-subtitle"  style="text-align:left; margin-bottom:0;">Appointment Time: <?php echo  $appointment_time ?></p>
            <p class="login-subtitle"  style="text-align:left; margin-bottom:0;">Price: <?php echo  $Price?></p>
            <br>

            <form id="checkout" action="../actions/ConfirmService.php" method="POST">
                <h1>Checkout</h1>
                <input id="name" name="name" type="text" placeholder="<?php echo  $_SESSION['Name']?>" value="<?php echo  $_SESSION['Name']?>">
                <input id="cardNumber" name="card_number" type="text"  placeholder="Card Number">
                <input id="expiry" name="expiry" type="date" >
                <input id="cvc" name="cvc" type="text" placeholder="CVC" >
                <button class="login-button" type="submit">Pay</button>
            </form>
            
        </div>

    </main>

</body>

<script>
</script>

</html>