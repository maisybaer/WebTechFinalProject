<?php
session_start();


$Customer_ID = isset($_SESSION['Customer_ID']) ? $_SESSION['Customer_ID'] : null;
if (!$Customer_ID) {
    echo "<script>alert('You must be logged in to make a booking.');</script>";
    header("Location: ../view/Login.php");
    exit;
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta name='viewport' content="width=device-width inital-scale=1.0">
	<title>Services</title>
	<link rel="icon" type="image/x-icon" href="..assets/favicon/favicon.ico">
	<link rel="stylesheet" href="../assets/css/Booking.css?v.1">
</head>

<body>
    <nav>
        <div class="grid-container-nav">
            <a href="Homepage.html"><div class="grid-item"><img class="logo" src="../assets/images/SammanLogo.png" alt="Samman Resorts Logo" style="width:70px; height:auto; margin:0px"></div></a>
            <a href="Booking.php"><div class="grid-item"><p>Book a room</p></div></a>
            <a href="Service.php"><div class="grid-item"><p>Book a service</p></div></a>
            <a href="MyBooking.php"><div class="grid-item"><p>My Bookings</p></div></a>
            <a href="AdminLogin.html"><div class="grid-item"><p>Admin</p></div></a>
            <a href="../action/Logout.php"><div class="grid-item"><p>Logout</p></div></a>
        </div>
    </nav>

    <main>

        <div class="login-card">
        <h2>Welcome <?php echo  $_SESSION['Name']?></h2>

            <form id="booking" action="../actions/PendingService.php" method="POST">
                <h1>Book a Service</h1>
                <p class="login-subtitle">Select your location</p>
                <select id="Branch_ID" name="Branch_ID">
                    <option value="">Branch</option>
                    <option value="B001">Accra</option>
                    <option value="B002">Koforidua</option>
                    <option value="B003">Kwahu</option>
                    <option value="B004">Kumasi</option>
                </select>

                <p class="login-subtitle">Select your service</p>
                <select id="service_ID" name="service_ID">
                    <option value="">Service</option>
                    <option value="S001">Full Body Massage</option>
                    <option value="S002">Aromatherapy Spa Session</option>
                    <option value="S003">Gym</option>
                    <option value="S004">Yoga Class</option>
                    <option value="S005">Pool</option>
                    <option value="S006">Sauna Session</option>
                    <option value="S007">Manicure</option>
                    <option value="S008">Pedicure</option>
                    <option value="S009">Guided Tour</option>
                    <option value="S0010">Conference Room</option>
                </select>

                <p class="login-subtitle">Book your dates</p>
                
                <p class="plain">Appointment Date<p>
                <input type="date" class="input" id="appointment_date" name="appointment_date"  required>

                <p class="plain">Appointment Time<p>
                <input type="time" class="input" id="appointment_time" name="appointment_time" required>
                

                <button class="login-button" type="submit">Book</button>
            </form>
            
        </div>

    </main>

</body>

<script>

function validateTime() {
        const appointmentTime = document.getElementById("appointment_time").value;
        const appointmentDate = document.getElementById("appointment_date").value;
        const selectedTime = new Date(`${appointmentDate}T${appointmentTime}`);
        const startTime = new Date(`${appointmentDate}T08:00`);
        const endTime = new Date(`${appointmentDate}T18:00`);

        if (selectedTime < startTime || selectedTime > endTime) {
            alert("Please select a time between 8:00 AM and 6:00 PM.");
            return false;
        }

        const todayDate=new Date().toISOString().split('T')[0];
        if (appointmentDate< todayDate) {
            alert("Check-in date cannot be before today's date.");
            return false;
        }

        return true;
    }

    document.getElementById("booking").addEventListener("submit", function(event) {
        if (!validateTime()) {
            event.preventDefault(); 
        }
    });
</script>

</html>