<!DOCTYPE html>
<html>
<head>
	<meta name='viewport' content="width=device-width inital-scale=1.0">
	<title>Login</title>
	<link rel="icon" type="image/x-icon" href="..assets/favicon/favicon.ico">
	<link rel="stylesheet" href="../assets/css/Booking.css?v.1">
</head>

<body>

    <nav style="text-align:right">
            <a href="AdminLogin.html"><button style="width:100px; margin: 10px">Admin</button></a>
    </nav>

    <main>

        <div class="login-card" >
            <img src="../assets/images/SammanLogo.png" alt="Samman Logo">
            <h1>Welcome to Samman Resort</h1>
            <p class="login-subtitle">Enter your email to login</p>
            
            <form id="login" action="../actions/UserLogin.php" method="post">
                <input id="Email" name="Email" type="email" class="input" placeholder="Email" required>
                <input id="pword" name="pword" type="password" class="input" placeholder="Password" required>
                <button class="login-button" type="submit" name="submitBtn" id="submitBtn">Login</button>
            </form>

            <div class="divider">
                <span>Don't have an account yet</span>
            </div>
    
                <a href="Signup.html"><button class="white-button">Sign up</button></a>
    
            <p class="terms">
                By clicking continue, you agree to our 
                <a href="#">Terms of Service</a> and 
                <a href="#">Privacy Policy</a>
            </p>
            <br>

        </div>

    </main>

</body>

<script>
const form = document.getElementById("login");

form.addEventListener("submit", function (event) {
    event.preventDefault();

    const Email = document.getElementById("Email").value;
    const pword = document.getElementById("pword").value;

    if (Email === "") {
        alert("Please enter your Email.");
        return;
    }

    if (pword === "") {
        alert("Please enter your password.");
        return;
    }

    form.submit();
});
</script>

</html>
