<?php
session_start();



$Customer_ID = isset($_SESSION['Customer_ID']) ? $_SESSION['Customer_ID'] : null;
if (!$Customer_ID) {
    echo "<script>alert('You must be logged in to make a booking.');</script>";
    header("Location: ../view/Login.php");
    exit;
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta name='viewport' content="width=device-width inital-scale=1.0">
	<title>Booking</title>
	<link rel="icon" type="image/x-icon" href="..assets/favicon/favicon.ico">
	<link rel="stylesheet" href="../assets/css/Booking.css?v.1">
</head>

<body>
    <nav>
        <div class="grid-container-nav">
            <a href="Homepage.html"><div class="grid-item"><img id="logo" src="../assets/images/SammanLogo.png" alt="Samman Resorts Logo" style="width:70px; height:auto; margin:0px" ></div></a>
            <a href="Booking.php"><div class="grid-item"><p>Book a room</p></div></a>
            <a href="Service.php"><div class="grid-item"><p>Book a service</p></div></a>
            <a href="MyBooking.php"><div class="grid-item"><p>My Bookings</p></div></a>
            <a href="AdminLogin.html"><div class="grid-item"><p>Admin</p></div></a>
            <a href="../action/Logout.php"><div class="grid-item"><p>Logout</p></div></a>
        </div>
    </nav>

    <main>

        <div class="login-card">
        <h2>Welcome <?php echo  $_SESSION['Name']?></h2>

            <form id="booking" action="../actions/PendingBooking.php" method="POST" onsubmit="return validateForm()">
                <h1>Book your Stay</h1>
                <p class="login-subtitle">Select your location</p>
                <select id="Branch_ID" name="Branch_ID" required>
                    <option value="">Branch</option>
                    <option value="B001">Accra</option>
                    <option value="B002">Koforidua</option>
                    <option value="B003">Kwahu</option>
                    <option value="B004">Kumasi</option>
                </select>

                <p class="login-subtitle">Select your room</p>
                <select id="Room_ID" name="Room_ID" required>
                    <option value="">Room Type</option>
                    <option value="R001">Deluxe</option>
                    <option value="R002">Superior</option>
                    <option value="R003">Executive</option>
                    <option value="R004">Standard</option>
                    <option value="R005">Family</option>
                    <option value="R006">Junior</option>
                    <option value="R007">Economy</option>
                </select>

                <p class="login-subtitle">Book your dates</p>
                
                <p class="plain">Check in date<p>
                <input type="date" class="input" id="Check_In_Date" name="Check_In_Date" required>

                <p class="plain">Check out date<p>
                <input type="date" class="input" id="Check_Out_Date" name="Check_Out_Date" required>
                
                <button class="login-button" type="submit">Book</button>
            </form>
            
        </div>

    </main>

</body>

<script>
    function validateForm(){
        const Branch_ID=document.getElementById("Branch_ID").value;
        const Room_ID=document.getElementById("Room_ID").value;
        const Check_In_Date=document.getElementById("Check_In_Date").value;
        const Check_Out_Date=document.getElementById("Check_Out_Date").value;

        if (!Branch_ID){
            alert("Please select a branch.");
            return false;
        }

        if (!Room_ID){
            alert("Please select a room.");
            return false;
        }

        const todayDate=new Date().toISOString().split('T')[0];
        if (Check_In_Date< todayDate) {
            alert("Check-in date cannot be before today's date.");
            return false;
        }

        if (Check_Out_Date<=Check_In_Date){
            alert("Check-out date must be after the check-in date.");
            return false;
        }

        return true;
    }
</script>

</html>