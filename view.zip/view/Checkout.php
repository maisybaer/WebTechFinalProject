<?php
session_start();
include '../db/api.php';



$sql = "SELECT pb.*, r.Room_Name 
FROM pending_booking pb
LEFT JOIN room r ON pb.Room_ID = r.Room_ID";
$result = $conn->query($sql);

//insert into table
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $Branch_Location= $row['Branch_Location']?? 'N/A';
        $Room_Name= $row['Room_Name']?? 'N/A';
        $Branch_ID = $row['Branch_ID']?? 'N/A';
        $Room_ID = $row['Room_ID']?? 'N/A';
        $Check_In_Date = $row['Check_In_Date'] ?? 'N/A';
        $Check_Out_Date= $row['Check_Out_Date']?? 'N/A';
        $Price = $row['Price']?? 'N/A';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta name='viewport' content="width=device-width inital-scale=1.0">
	<title>Booking</title>
	<link rel="icon" type="image/x-icon" href="..assets/favicon/favicon.ico">
	<link rel="stylesheet" href="../assets/css/Booking.css?v.1">
</head>

<body>
    <nav>
        <div class="grid-container-nav">
            <a href="Homepage.html"><div class="grid-item"><img class="logo" src="../assets/images/SammanLogo.png" alt="Samman Resorts Logo" style="width:70px; height:auto; margin:0px"></div></a>
            <a href="AboutUs.html"><div class="grid-item"><p>About</p></div></a>
            <a href="Rooms.html"><div class="grid-item"><p>Rooms</p></div></a>
            <a href="Facilities.html"><div class="grid-item"><p>Facilities</p></div></a>
            <a href="Login.html"><div class="grid-item"><p>Booking</p></div></a>
        </div>
    </nav>

    <main>

        <div class="login-card">
            <h1>Your Booking</h1>
            <p class="login-subtitle"  style="text-align:left; margin-bottom:0;">Location: <?php echo  $Branch_Location?></p>
            <p class="login-subtitle"  style="text-align:left; margin-bottom:0;">Room: <?php echo  $Room_Name?></p>
            <p class="login-subtitle"  style="text-align:left; margin-bottom:0;">Check in date: <?php echo  $Check_In_Date ?></p>
            <p class="login-subtitle"  style="text-align:left; margin-bottom:0;">Check out date: <?php echo  $Check_Out_Date ?></p>
            <p class="login-subtitle"  style="text-align:left; margin-bottom:0;">Price: GHS<?php echo  $Price?></p>
            <br>

            <form id="checkout" action="../actions/ConfirmBooking.php" method="POST">
                <h1>Checkout</h1>
                <input id="name" name="name" type="text" placeholder="<?php echo  $_SESSION['Name']?>" value="<?php echo  $_SESSION['Name']?>">
                <input id="cardNumber" name="card_number" type="text"  placeholder="Card Number">
                <input id="expiry" name="expiry" type="date" >
                <input id="cvc" name="cvc" type="text" placeholder="CVC" >
                <button class="login-button" type="submit">Pay</button>
            </form>
            
        </div>

    </main>

</body>

<script>
</script>

</html>