<?php
session_start();
require "../db/api.php";

// Function to fetch bookings
function fetchBooking($conn) {
    $query = "SELECT rb.*, c.First_Name, c.Last_Name, b.Branch_Location, r.Room_Name, r.Price 
              FROM room_booking rb
              LEFT JOIN customer c ON rb.Customer_ID = c.Customer_ID
              LEFT JOIN branches b ON rb.Branch_ID = b.Branch_ID
              LEFT JOIN room r ON rb.Room_ID = r.Room_ID";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();
    $bookings = [];
    while ($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
    $stmt->close();
    return $bookings;
}

$bookings = fetchBooking($conn);

// Update booking
if (isset($_POST['edit-btn'])) {
    $room_booking_ID = $_POST['room_booking_ID']; 
    $Branch_ID = $_POST['Branch_ID']; 
    $Room_ID = $_POST['Room_ID']; 
    $Check_In_Date = $_POST['Check_In_Date']; 
    $Check_Out_Date = $_POST['Check_Out_Date']; 

    $updateSQL = "UPDATE room_booking SET Branch_ID=?, Room_ID=?, Check_In_Date=?, Check_Out_Date=? WHERE room_booking_ID=?";
    $stmt = $conn->prepare($updateSQL);
    $stmt->bind_param("ssssi", $Branch_ID, $Room_ID, $Check_In_Date, $Check_Out_Date, $room_booking_ID);
    $stmt->execute();
    $stmt->close();

    header("Location: AdminBooking.php");
}

// Delete booking
if (isset($_POST['delete-btn'])) {
    $room_booking_ID = $_POST['room_booking_ID']; 
    $deleteSQL = "DELETE FROM room_booking WHERE room_booking_ID=?";
    $stmt = $conn->prepare($deleteSQL);
    $stmt->bind_param("i", $room_booking_ID);
    $stmt->execute();
    $stmt->close();

    // Update room status
    $stmtUpdate = $conn->prepare("UPDATE room SET Room_Status = Room_Status + 1 WHERE Room_ID = ?");
    $stmtUpdate->bind_param("s", $_POST['Room_ID']);
    if ($stmtUpdate->execute()) {
        header("Location: AdminBooking.php");
        exit;
    } else {
        echo "<script>alert('An error occurred while updating room status.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Booking</title>
    <link rel="icon" type="image/x-icon" href="../assets/favicon/favicon.ico">
    <link rel="stylesheet" href="../assets/css/AdminDashboard.css?v.1">
</head>
<body>

<div class="page-grid-container">
    <!-- Menu -->
    <div name="menu" class="item2">
        <a href="Homepage.html"><img class="logo" src="../assets/images/SammanLogo.png" alt="Samman Resorts Logo" style="width:100px; height:auto;"></a>
        <p id="title">Menu</p>
        <a href="AdminBooking.php"><div class="grid-item"><p>Booking</p></div></a>
        <a href="AdminServices.php"><div class="grid-item"><p>Services</p></div></a>
        <a href="../actions/Logout.php"><div class="grid-item"><p>Logout</p></div></a>
    </div>

    <!-- Header -->
    <div name="header" class="item1">
        <h1>Bookings</h1>
        <p>Manage your bookings</p>
    </div>

    <!-- Main content -->
    <div name="main" class="item3">
        <table id="inventoryTable">
            <thead>
                <tr>
                    <th>Booking ID</th>
                    <th>Customer</th>
                    <th>Branch</th>
                    <th>Room</th>
                    <th>Check In</th>
                    <th>Check Out</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($bookings as $item): ?>
                    <tr>
                        <td>RB<?php echo htmlspecialchars($item['room_booking_ID']); ?></td>
                        <td>C<?php echo htmlspecialchars($item['Customer_ID']); ?></td>
                        <td><?php echo htmlspecialchars($item['Branch_Location']); ?></td>
                        <td><?php echo htmlspecialchars($item['Room_ID']); ?></td>
                        <td><?php echo htmlspecialchars($item['Check_In_Date']); ?></td>
                        <td><?php echo htmlspecialchars($item['Check_Out_Date']); ?></td>
                        <td>
                            <!-- View Details Popup -->
                            <button class="action" onclick="openDetails('<?php echo $item['room_booking_ID']; ?>')">Details</button>
                            <div id="details-popup-<?php echo $item['room_booking_ID']; ?>" class="popup" style="display:none;">
                                <div class="popup-content" style="text-align:left;">
                                    <input type="hidden" name="room_booking_ID" value="<?php echo htmlspecialchars($item['room_booking_ID']); ?>">
                                    <h1>Booking Details</h1>
                                    <p class="login-subtitle">Branch ID: <?php echo htmlspecialchars($item['Branch_ID']); ?> </p>
                                    <p class="login-subtitle">Room Name: <?php echo htmlspecialchars($item['Room_Name']); ?> </p>
                                    <p class="login-subtitle">Customer Name: <?php echo htmlspecialchars($item['First_Name'] . ' ' . $item['Last_Name']); ?> </p>
                                    <p class="login-subtitle">Price: GHS<?php echo htmlspecialchars($item['Price']); ?> </p>
                                    <button class="white-button" type="button" onclick="closeDetails('<?php echo $item['room_booking_ID']; ?>')">Close</button>
                                </div>
                            </div>

                            <!-- Edit Booking Popup -->
                            <button class="action" onclick="openUpdate('<?php echo $item['room_booking_ID']; ?>')">Edit</button>
                            <div id="edit-popup-<?php echo $item['room_booking_ID']; ?>" class="popup" style="display:none;">
                                <form class="popup-content" method="POST" action="">
                                    <h1>Edit Booking</h1>
                                    <input type="hidden" name="room_booking_ID" value="<?php echo htmlspecialchars($item['room_booking_ID']); ?>">
                                    <p class="login-subtitle">Select your location</p>
                                    <select name="Branch_ID" required>
                                        <option value="">Branch</option>
                                        <option value="B001" <?php echo ($item['Branch_ID'] == 'B001' ? 'selected' : ''); ?>>Accra</option>
                                        <option value="B002" <?php echo ($item['Branch_ID'] == 'B002' ? 'selected' : ''); ?>>Koforidua</option>
                                        <option value="B003" <?php echo ($item['Branch_ID'] == 'B003' ? 'selected' : ''); ?>>Kwahu</option>
                                        <option value="B004" <?php echo ($item['Branch_ID'] == 'B004' ? 'selected' : ''); ?>>Kumasi</option>
                                    </select>
                                    <p class="login-subtitle">Select your room</p>
                                    <select name="Room_ID" required>
                                        <option value="">Room Type</option>
                                        <option value="R001" <?php echo ($item['Room_ID'] == 'R001' ? 'selected' : ''); ?>>Deluxe</option>
                                        <option value="R002" <?php echo ($item['Room_ID'] == 'R002' ? 'selected' : ''); ?>>Superior</option>
                                        <option value="R003" <?php echo ($item['Room_ID'] == 'R003' ? 'selected' : ''); ?>>Executive</option>
                                        <option value="R004" <?php echo ($item['Room_ID'] == 'R004' ? 'selected' : ''); ?>>Standard</option>
                                        <option value="R005" <?php echo ($item['Room_ID'] == 'R005' ? 'selected' : ''); ?>>Family</option>
                                        <option value="R006" <?php echo ($item['Room_ID'] == 'R006' ? 'selected' : ''); ?>>Junior</option>
                                        <option value="R007" <?php echo ($item['Room_ID'] == 'R007' ? 'selected' : ''); ?>>Economy</option>
                                    </select>

                                    <p class="login-subtitle">Check in date</p>
                                    <input type="date" name="Check_In_Date" required>
                                  
                                    <p class="login-subtitle">Check out date</p>
                                    <input type="date" name="Check_Out_Date" required>
                                   
                                    <button type="submit" name="edit-btn">Update</button>
                                    <button class="white-button" type="button" onclick="closeUpdate('<?php echo $item['room_booking_ID']; ?>')">Cancel</button>
                                </form>
                            </div>

                            <!-- Delete Booking Popup -->
                            <button class="action" onclick="openDelete('<?php echo $item['room_booking_ID']; ?>')">Delete</button>
                            <div id="delete-popup-<?php echo $item['room_booking_ID']; ?>" class="popup" style="display:none;">
                                <form class="popup-content" method="POST" action="">
                                    <input type="hidden" name="room_booking_ID" value="<?php echo htmlspecialchars($item['room_booking_ID']); ?>">
                                    <h1>Delete Booking</h1>
                                    <p>Are you sure you want to delete this booking?</p>
                                    <br>
                                    <button type="submit" name="delete-btn" class="delete-btn">Delete</button>
                                    <button class="white-button" type="button" onclick="closeDelete('<?php echo $item['room_booking_ID']; ?>')">Cancel</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
// Open and close popups
function openUpdate(id) {
    document.getElementById('edit-popup-' + id).style.display = 'block';
}
function closeUpdate(id) {
    document.getElementById('edit-popup-' + id).style.display = 'none';
}

function openDelete(id) {
    document.getElementById('delete-popup-' + id).style.display = 'block';
}
function closeDelete(id) {
    document.getElementById('delete-popup-' + id).style.display = 'none';
}

function openDetails(id) {
    document.getElementById('details-popup-' + id).style.display = 'block';
}
function closeDetails(id) {
    document.getElementById('details-popup-' + id).style.display = 'none';
}
</script>

</body>
</html>

